#include<Stdio.h>
int main(){
	printf("hello world");
}
